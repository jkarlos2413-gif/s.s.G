from dotenv import load_dotenv
import oracledb
import os

class OracleMetodos:
    def __init__(self, env_file=".env.development"):
        # Cargar las variables de entorno
        load_dotenv(env_file)
        self.user = os.getenv("DB_USER")
        self.password = os.getenv("DB_PASSWORD")
        self.host = os.getenv("DB_HOST")
        self.service_name = os.getenv("DB_SERVICE_NAME")
        self.port = os.getenv("DB_PORT")
        self._crear_dsn()
        
        # Validar configuración requerida
        if not all([self.user, self.password, self.dsn]):
            raise ValueError("Faltan configuraciones requeridas (USER, PASSWORD, DSN).")
        
    def _crear_dsn(self):
        """
        Método privado para crear el DSN de conexión.
        """
        self.dsn = (
            "(DESCRIPTION="
            f"(ADDRESS=(PROTOCOL=tcps)(HOST={self.host})(PORT={self.port}))"
            f"(CONNECT_DATA=(SERVICE_NAME={self.service_name}))"
            "(SECURITY=(SSL_SERVER_CERT_DN_MATCH=yes))"
            ")"
        )

    def connect(self):
        """Establece y retorna una conexión a la base de datos Oracle."""
        try:
            self.connection = oracledb.connect(
                user=self.user,
                password=self.password,
                dsn=self.dsn
            )            
            print("Conexión exitosa a Oracle Cloud")
            return self.connection        
        except oracledb.DatabaseError as e:
            print(f"Error al conectar a la base de datos: {e}")
            return None
