from Metodos.OracleMetodos import OracleMetodos

if __name__ == "__main__":
    db = OracleMetodos()
    connection = db.connect()